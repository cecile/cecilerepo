This AddOn is discontinued, download the new improved version, with more features: Cecile_MeterOverlay

Created by Cecile - Zul'Jin - EU
https://github.com/cecile