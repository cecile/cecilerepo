if not IsAddOnLoaded( "ElvUI" )  then return end
if not IsAddOnLoaded( "TinyDPS" )  then return end
if not IsAddOnLoaded( "ElvUI_MeterOverlay" )  then return end
